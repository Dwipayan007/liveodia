﻿
LiveOdiaApp.controller('aboutController', ['$scope', function ($scope) {


}]);