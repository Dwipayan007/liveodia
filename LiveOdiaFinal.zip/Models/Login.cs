﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LiveOdiaFinal.Models
{
    public class Login
    {
        public string USERNAME { get; set; }
        public string PASSWORD { get; set; }
        public string USERROLE { get; set; }
    }
}