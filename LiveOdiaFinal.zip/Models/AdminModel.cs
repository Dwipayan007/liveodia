﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LiveOdiaFinal.Models
{
    public class AdminModel
    {
        public string CNAME { get; set; }
        public string newsdate { get; set; }
    }
}